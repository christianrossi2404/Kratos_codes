from __future__ import print_function, absolute_import, division #makes KratosMultiphysics backward compatible with python 2.6 and 2.7
# importing the Kratos Library
from KratosMultiphysics import *
from KratosMultiphysics.FSIApplication import *
# Check that KratosMultiphysics was imported in the main script
CheckForPreviousImport()


def AddVariables(fluid_model_part, structure_model_part):
    fluid_model_part.AddNodalSolutionStepVariable(PRESSURE)
    fluid_model_part.AddNodalSolutionStepVariable(DISPLACEMENT)
    fluid_model_part.AddNodalSolutionStepVariable(MAPPER_SCALAR_PROJECTION_RHS)
    fluid_model_part.AddNodalSolutionStepVariable(MAPPER_VECTOR_PROJECTION_RHS)
    fluid_model_part.AddNodalSolutionStepVariable(VAUX_EQ_TRACTION)
    fluid_model_part.AddNodalSolutionStepVariable(IS_INTERFACE)
    fluid_model_part.AddNodalSolutionStepVariable(NORMAL)
    fluid_model_part.AddNodalSolutionStepVariable(SCALAR_PROJECTED)
    fluid_model_part.AddNodalSolutionStepVariable(VECTOR_PROJECTED)

    structure_model_part.AddNodalSolutionStepVariable(PRESSURE)
    structure_model_part.AddNodalSolutionStepVariable(DISPLACEMENT)
    structure_model_part.AddNodalSolutionStepVariable(MAPPER_SCALAR_PROJECTION_RHS)
    structure_model_part.AddNodalSolutionStepVariable(MAPPER_VECTOR_PROJECTION_RHS)
    structure_model_part.AddNodalSolutionStepVariable(VAUX_EQ_TRACTION)
    structure_model_part.AddNodalSolutionStepVariable(IS_INTERFACE)
    structure_model_part.AddNodalSolutionStepVariable(NORMAL)
    structure_model_part.AddNodalSolutionStepVariable(SCALAR_PROJECTED)
    structure_model_part.AddNodalSolutionStepVariable(VECTOR_PROJECTED)

    print("Mapper variables added correctly.")


class NonConformant_OneSideMap:

    def __init__(self, fluid_model_part, structure_model_part,
                 search_radius_factor=2.0, it_max=25, tol=1e-5):

        # Error check
        if fluid_model_part.NumberOfConditions(0) < 1:
            raise ValueError("No conditions found in the fluid model part, please check that the interface is meshed using SurfaceCondition2D2N/SurfaceCondition3D3N")
        if structure_model_part.NumberOfConditions(0) < 1:
            raise ValueError("No conditions found in the structure model part, please check that the interface is meshed using SurfaceCondition2D2N/SurfaceCondition3D3N")

        search_radius_factor = search_radius_factor
        self.it_max = it_max
        self.tol = tol

        self.Preprocess = InterfacePreprocess()
        self.fl_interface = ModelPart("fluid_interface")
        self.str_interface = ModelPart("structure_interface")

        domain_size_fl = fluid_model_part.ProcessInfo[DOMAIN_SIZE]
        domain_size_str = structure_model_part.ProcessInfo[DOMAIN_SIZE]

        if (domain_size_fl != domain_size_fl):
          raise ValueError("Domain sizes from two model parts are not compatible")

        print("Identifying fluid interface...")
        if (domain_size_fl == 3):
          self.Preprocess.GenerateTriangleInterfacePart(fluid_model_part, self.fl_interface)
        else:
          self.Preprocess.GenerateLineInterfacePart(fluid_model_part, self.fl_interface)

        print("Identifying structure interface...")
        if (domain_size_fl == 3):
          self.Preprocess.GenerateTriangleInterfacePart(structure_model_part, self.str_interface)
        else:
          self.Preprocess.GenerateLineInterfacePart(structure_model_part, self.str_interface)
        print("Fluid and structure interfaces identified.")

        # Interface mappers construction
        self.FluidToStructureMapper = AdvancedNMPointsMapper\
            (self.fl_interface, self.str_interface)
        self.StructureToFluidMapper = AdvancedNMPointsMapper\
            (self.str_interface, self.fl_interface)
        print("Interface Mappers created.")

        # Neighbour search
        (self.FluidToStructureMapper).FindNeighbours(search_radius_factor)
        (self.StructureToFluidMapper).FindNeighbours(search_radius_factor)
        print("Neighbours search finished.")

    def RecomputeTransferPairs(self, search_radius_factor):
        (self.FluidToStructureMapper).FindNeighbours(search_radius_factor)
        (self.StructureToFluidMapper).FindNeighbours(search_radius_factor)

    # Standard mappers
    def StructureToFluid_VectorMap(self, VectorVar_Origin, VectorVar_Destination, sign_pos, distributed):
        (self.StructureToFluidMapper).VectorMap(VectorVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos, distributed)

    def StructureToFluid_ScalarMap(self, ScalarVar_Origin, ScalarVar_Destination, sign_pos):
        (self.StructureToFluidMapper).ScalarMap(ScalarVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    def FluidToStructure_VectorMap(self, VectorVar_Origin, VectorVar_Destination, sign_pos, distributed):
        (self.FluidToStructureMapper).VectorMap(VectorVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos, distributed)

    def FluidToStructure_ScalarMap(self, ScalarVar_Origin, ScalarVar_Destination, sign_pos):
        (self.FluidToStructureMapper).ScalarMap(ScalarVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    # Normal vectors
    def StructureToFluid_ScalarToNormalVectorMap(self, ScalarVar_Origin, VectorVar_Destination, sign_pos):
        (self.StructureToFluidMapper).ScalarToNormalVectorMap(ScalarVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos)

    def StructureToFluid_NormalVectorToScalarMap(self, VectorVar_Origin, ScalarVar_Destination, sign_pos):
        (self.StructureToFluidMapper).NormalVectorToScalarMap(VectorVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    def FluidToStructure_ScalarToNormalVectorMap(self, ScalarVar_Origin, VectorVar_Destination, sign_pos):
        (self.FluidToStructureMapper).ScalarToNormalVectorMap(ScalarVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos)

    def FluidToStructure_NormalVectorToScalarMap(self, VectorVar_Origin, ScalarVar_Destination, sign_pos):
        (self.FluidToStructureMapper).NormalVectorToScalarMap(VectorVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)


class NonConformantTwoFaces_OneSideMap:

    def __init__(self, fluid_model_part_positive, fluid_model_part_negative, structure_model_part,
                 search_radius_factor=2.0, it_max=25, tol=1e-5):

        # Error check
        if fluid_model_part_positive.NumberOfConditions(0) < 1:
            raise ValueError("No conditions found in the positive interface fluid model part, please check that the interface is meshed.")
        if fluid_model_part_negative.NumberOfConditions(0) < 1:
            raise ValueError("No conditions found in the negative interface fluid model part, please check that the interface is meshed.")
        if structure_model_part.NumberOfConditions(0) < 1:
            raise ValueError("No conditions found in the structure interface model part, please check that the interface is meshed.")

        self.search_radius_factor = search_radius_factor
        self.it_max = it_max
        self.tol = tol

        self.PositiveFluidToStructureMapper = AdvancedNMPointsMapper(fluid_model_part_positive, structure_model_part)
        self.NegativeFluidToStructureMapper = AdvancedNMPointsMapper(fluid_model_part_negative, structure_model_part)
        self.StructureToPositiveFluidMapper = AdvancedNMPointsMapper(structure_model_part, fluid_model_part_positive)
        self.StructureToNegativeFluidMapper = AdvancedNMPointsMapper(structure_model_part, fluid_model_part_negative)
        print("Interface Mappers created.")

        # Neighbour search
        (self.PositiveFluidToStructureMapper).FindNeighbours(self.search_radius_factor)
        (self.NegativeFluidToStructureMapper).FindNeighbours(self.search_radius_factor)
        (self.StructureToPositiveFluidMapper).FindNeighbours(self.search_radius_factor)
        (self.StructureToNegativeFluidMapper).FindNeighbours(self.search_radius_factor)
        print("Neighbours search finished.")

    def RecomputeTransferPairs(self, search_radius_factor=2.0):
        (self.PositiveFluidToStructureMapper).FindNeighbours(search_radius_factor)
        (self.NegativeFluidToStructureMapper).FindNeighbours(search_radius_factor)
        (self.StructureToPositiveFluidMapper).FindNeighbours(search_radius_factor)
        (self.StructureToNegativeFluidMapper).FindNeighbours(search_radius_factor)

    # Standard mappers for positive fluid face
    def StructureToPositiveFluid_VectorMap(self, VectorVar_Origin, VectorVar_Destination, sign_pos, distributed):
        (self.StructureToPositiveFluidMapper).VectorMap(VectorVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos, distributed)

    def StructureToPositiveFluid_ScalarMap(self, ScalarVar_Origin, ScalarVar_Destination, sign_pos):
        (self.StructureToPositiveFluidMapper).ScalarMap(ScalarVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    def PositiveFluidToStructure_VectorMap(self, VectorVar_Origin, VectorVar_Destination, sign_pos, distributed):
        (self.PositiveFluidToStructureMapper).VectorMap(VectorVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos, distributed)

    def PositiveFluidToStructure_ScalarMap(self, ScalarVar_Origin, ScalarVar_Destination, sign_pos):
        (self.PositiveFluidToStructureMapper).ScalarMap(ScalarVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    # Standard mappers for negative fluid face
    def StructureToNegativeFluid_VectorMap(self, VectorVar_Origin, VectorVar_Destination, sign_pos, distributed):
        (self.StructureToNegativeFluidMapper).VectorMap(VectorVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos, distributed)

    def StructureToNegativeFluid_ScalarMap(self, ScalarVar_Origin, ScalarVar_Destination, sign_pos):
        (self.StructureToNegativeFluidMapper).ScalarMap(ScalarVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    def NegativeFluidToStructure_VectorMap(self, VectorVar_Origin, VectorVar_Destination, sign_pos, distributed):
        (self.NegativeFluidToStructureMapper).VectorMap(VectorVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos, distributed)

    def NegativeFluidToStructure_ScalarMap(self, ScalarVar_Origin, ScalarVar_Destination, sign_pos):
        (self.NegativeFluidToStructureMapper).ScalarMap(ScalarVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    # Normal vectors mappers for positive fluid face
    def StructureToPositiveFluid_ScalarToNormalVectorMap(self, ScalarVar_Origin, VectorVar_Destination, sign_pos):
        (self.StructureToPositiveFluidMapper).ScalarToNormalVectorMap(ScalarVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos)

    def StructureToPositiveFluid_NormalVectorToScalarMap(self, VectorVar_Origin, ScalarVar_Destination, sign_pos):
        (self.StructureToPositiveFluidMapper).NormalVectorToScalarMap(VectorVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    def PositiveFluidToStructure_ScalarToNormalVectorMap(self, ScalarVar_Origin, VectorVar_Destination, sign_pos):
        (self.PositiveFluidToStructureMapper).ScalarToNormalVectorMap(ScalarVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos)

    def PositiveFluidToStructure_NormalVectorToScalarMap(self, VectorVar_Origin, ScalarVar_Destination, sign_pos):
        (self.PositiveFluidToStructureMapper).NormalVectorToScalarMap(VectorVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    # Normal vectors mappers for negative fluid face
    def StructureToNegativeFluid_ScalarToNormalVectorMap(self, ScalarVar_Origin, VectorVar_Destination, sign_pos):
        (self.StructureToNegativeFluidMapper).ScalarToNormalVectorMap(ScalarVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos)

    def StructureToNegativeFluid_NormalVectorToScalarMap(self, VectorVar_Origin, ScalarVar_Destination, sign_pos):
        (self.StructureToNegativeFluidMapper).NormalVectorToScalarMap(VectorVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)

    def NegativeFluidToStructure_ScalarToNormalVectorMap(self, ScalarVar_Origin, VectorVar_Destination, sign_pos):
        (self.NegativeFluidToStructureMapper).ScalarToNormalVectorMap(ScalarVar_Origin, VectorVar_Destination, self.it_max, self.tol, sign_pos)

    def NegativeFluidToStructure_NormalVectorToScalarMap(self, VectorVar_Origin, ScalarVar_Destination, sign_pos):
        (self.NegativeFluidToStructureMapper).NormalVectorToScalarMap(VectorVar_Origin, ScalarVar_Destination, self.it_max, self.tol, sign_pos)
